#include <QtCore/qglobal.h>
#if defined(DYNAMIC_LIBRARY)
#  define DYNAMIC_LIBRARY Q_DECL_EXPORT
#else
#  define DYNAMIC_LIBRARY Q_DECL_IMPORT
#endif

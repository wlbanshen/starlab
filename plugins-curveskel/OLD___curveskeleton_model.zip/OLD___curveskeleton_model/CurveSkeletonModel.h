#pragma once

#include <QDebug>
#include <QString>
#include "Model.h"
#include "SkeletonNode.h"
#include "SkeletonEdge.h"
#include "dynamic_library.h"

using namespace std;
#define Vector std::vector

class DYNAMIC_LIBRARY CurveSkeletonModel : public Model{
    Q_OBJECT
    Q_INTERFACES(Model)
    
    Vector<SkeletonNode> nodes;
    Vector<SkeletonEdge> edges;
   
public:
    CurveSkeletonModel(QString path, QString name=QString());
    void readFromFile(QString path);

public:
    virtual void render();
private:
    void render_nodes();
    void render_edges();
};
